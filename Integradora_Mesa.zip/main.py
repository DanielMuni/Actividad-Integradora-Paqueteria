from mesa import Agent, Model
from mesa.space import MultiGrid
from mesa.time import RandomActivation
from mesa.time import BaseScheduler
from mesa.visualization.modules import CanvasGrid
from mesa.visualization.ModularVisualization import ModularServer
from pathfinding.core.diagonal_movement import DiagonalMovement
from pathfinding.core.grid import Grid as PathGrid
from pathfinding.finder.a_star import AStarFinder
from mesa.visualization.UserParam import UserSettableParameter
from mesa.datacollection import DataCollector
from mesa.visualization.modules import ChartModule
from mesa.visualization.ModularVisualization import VisualizationElement
import random
from math import sqrt


def initMaxtrix(n,m):

  matrix = [ [ 1 for i in range(n) ] for j in range(m)]
 
  for i in range(n):
    matrix[0][i] = 0
    matrix[m-1][i] = 0

  
  for i in range(m):
    matrix[i][0] = 0
    matrix[i][n-1] = 0
  
  return matrix


class Robot(Agent):
    def __init__(self, model, pos):
        super().__init__(model.next_id(), model)
        self.name = "robot"
        self.condition = "libre"
        self.pos = pos
        self.contador_pasos = 0 
        self.roaming = False
        self.possible_steps = []
        self.siguientesPasos = []
        self.endX = 1
        self.endY = 1




    def buscarCaja(self):
      for neighbor in self.model.grid.neighbor_iter(self.pos, moore=False):
          if neighbor.condition == "Not Ready":
              return True
      return False

    def recogerCaja(self):
      self.condition = "Ocupado"
      for neighbor in self.model.grid.neighbor_iter(self.pos):
          if neighbor.condition == "Not Ready":
              self.caja = neighbor
              self.caja.condition = "En camino"
              break
      self.model.grid.move_agent(self.caja, self.pos)

    def caminoCasa(self, posX, posY):
      
      pathGrid = PathGrid(matrix=self.model.matrix)

      if(self.roaming == False):
        self.endX = posX
        self.endY = posY
        self.roaming = True

      start = pathGrid.node(self.pos[0],self.pos[1])
      end = pathGrid.node(self.endX,self.endY)

      finder = AStarFinder(diagonal_movement=DiagonalMovement.always)
      path, runs = finder.find_path(start, end, pathGrid)
      #print(path)
      if(len(path) > 1):
        next_move = path[1]
        self.contador_pasos += 1
        self.model.grid.move_agent(self, next_move)
        self.model.grid.move_agent(self.caja, next_move)
            
      else:
        self.roaming = False

        pathGrid.cleanup()


    def revisarCaja(self):
      if (self.pos == (1,1) or self.pos == (2,1) or self.pos == (3,1) or self.pos == (4,1) or self.pos == (5,1) or self.pos == (6,1) or self.pos == (7,1)):
        self.condition = "libre"
        self.caja.condition = "Entregada"
      else:

        
        self.posicionFinal = (1,random.randrange(1,7))
        self.caminoCasa(random.randrange(1,7),1)

        #for i in range(5):
        #  self.caminoCasa(i,1)
        

      

    def step(self):
      
      zeros = []
      self.grid = MultiGrid(15, 15, torus=False)     
      self.model.matrix
      zeros = [(x, y) for y in range(self.model.height) for x in range(self.model.width) if y in [0,self.model.height-1] or x in [0, self.model.width - 1]]

      next_moves = self.model.grid.get_neighborhood(self.pos, moore=False)
      next_move = self.random.choice(next_moves)

      if next_move in zeros:
        next_move = self.random.choice(next_moves)
      else:
        if self.condition == "libre":
          if self.buscarCaja():
            print("CAJA")
            self.recogerCaja()
          else:
            self.contador_pasos += 1
            self.model.grid.move_agent(self, next_move)
        elif self.condition == "Ocupado":
          print("Transportando Caja")
          self.revisarCaja()

              
                       


class Box(Agent):
    def __init__(self, model, pos):
        super().__init__(model.next_id(), model)
        self.pos = pos        
        if (self.pos == (1,1) or self.pos == (2,1) or self.pos == (3,1) or self.pos == (4,1) or self.pos == (5,1) or self.pos == (6,1) or self.pos == (7,1)):
            self.condition = "Entregado"
        else:
          self.condition = "Not Ready"

    def step(self):
      
      if (self.pos == (1,1) or self.pos == (2,1) or self.pos == (3,1) or self.pos == (4,1) or self.pos == (5,1) or self.pos == (6,1) or self.pos == (7,1)) :
        self.condition = "Entregado"
      else:
         self.condition = "Not Ready"

        

# Se define el agente de pared
class WallBlock(Agent):
    def __init__(self, model):
        super().__init__(self, model)
        self.condition = "Wall"

    def step(self):
        pass

# Se define el modelo Maze con los atributos dentro del constructor
class Maze(Model):
    def __init__(self, height=15, width=15, boxN=15, max_time=500):
        super().__init__()
        self.steps = 0
        self.max_time = max_time
        self.num_box = boxN
        self.height = height
        self.width = width
        self.running = True
        self.matrix = initMaxtrix(width,height);
        self.schedule = RandomActivation(self)
        self.grid = MultiGrid(width, height, torus=False)
        self.contadorPasos = 0

        
        muro = [(x, y) for y in range(height) for x in range(width) if y in [0, height-1] or x in [0, width - 1]]

        for pos in muro:
            wall = WallBlock(self)
            self.schedule.add(wall)
            self.grid.place_agent(wall, pos)

        for i in range(5):

            def pos_robot(w, h):
                for _,x,y in self.grid.coord_iter():
                    return (self.random.randrange(2,w), self.random.randrange(2,h))

            pos = pos_robot(self.grid.width, self.grid.height)

            while (not self.grid.is_cell_empty(pos)):
                pos = pos_robot(self.grid.width, self.grid.height)

            new_robot = Robot(self, pos)
            self.grid._place_agent(pos, new_robot)
            self.schedule.add(new_robot)
        
        #Agregar Cajas
        for i in range(self.num_box):

            def pos_box(w, h):
                return (self.random.randrange(w), self.random.randrange(h))

            pos = pos_box(self.grid.width, self.grid.height)

            while (not self.grid.is_cell_empty(pos)):
                pos = pos_box(self.grid.width, self.grid.height)

            new_box = Box(self, pos)
            self.grid._place_agent(pos, new_box)
            self.schedule.add(new_box)
            
        
    
    def step(self):
      self.contadorPasos += 1
      if (self.max_time <= 0 or self.restantes(self, "Entregado") == self.num_box):
        print("Final de simulacion")
        print("Número de movimientos realizados por todos los robots: ",self.contadorPasos*5)
        print("Tiempo total:", self.contadorPasos)
        self.running = False
      self.max_time -= 1
      self.schedule.step()
      

    @staticmethod
    def restantes(model, condition):
        count = 0
        for agent in model.schedule.agents:
            if agent.condition == condition:
                count += 1
        return count


    

def agent_portrayal(agent):
  if(type(agent) == Robot):
    return {"Shape": "robot.png", "Layer": 1}
  elif (type(agent) == Box):
    return {"Shape": "box.png", "Layer": 0}
  elif (type(agent) == WallBlock):
    return {"Shape": "walll2.png", "Layer": 0}

    # Se definen las variables de grid, chart, y server
grid = CanvasGrid(agent_portrayal, 15, 15, 450, 450)

server = ModularServer(Maze, [grid], "Robot")

server.port = 8522
server.launch()