using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public static class JsonHelper
{
    public static T[] FromJson<T>(string json)
    {
        Wrapper<T> wrapper = JsonUtility.FromJson<Wrapper<T>>(json);
        return wrapper.Items;
    }

    public static string ToJson<T>(T[] array)
    {
        Wrapper<T> wrapper = new Wrapper<T>();
        wrapper.Items = array;
        return JsonUtility.ToJson(wrapper);
    }

    public static string ToJson<T>(T[] array, bool prettyPrint)
    {
        Wrapper<T> wrapper = new Wrapper<T>();
        wrapper.Items = array;
        return JsonUtility.ToJson(wrapper, prettyPrint);
    }

    [System.Serializable]
    private class Wrapper<T>
    {
        public T[] Items;
    }
}

[System.Serializable]
class MyRobot
{
    public int x;
    public int y;

    override public string ToString()
    {
        return "X: " + x + ", Y: " + y;
    }
}

public class MoverModelo : MonoBehaviour
{
    string simulationURL = null;
    private float waitTime = 0.3f;
    private float timer = 0.0f;
    public GameObject[] Robot;


    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(ConnectToMesa());
    }

    IEnumerator ConnectToMesa()
    {
        WWWForm form = new WWWForm();

        using (UnityWebRequest www = UnityWebRequest.Post("http://localhost:5000/games", form))
        {
            yield return www.SendWebRequest();

            if (www.result != UnityWebRequest.Result.Success)
            {
                Debug.Log(www.error);
            }
            else
            {
                simulationURL = www.GetResponseHeader("Location");
                Debug.Log("Connected to simulation through Web API");
                Debug.Log(simulationURL);
            }
        }
    }

    IEnumerator UpdatePositions()
    {
        using (UnityWebRequest www = UnityWebRequest.Get(simulationURL))
        {
            if (simulationURL != null)
            {
                // Request and wait for the desired page.
                yield return www.SendWebRequest();

                //Debug.Log(www.downloadHandler.text);
                Debug.Log("Data has been processed");
                MyRobot[] robots = JsonHelper.FromJson<MyRobot>(www.downloadHandler.text);
                
                //Debug.Log(Robot[0].ToString());

                //Debug.Log(robots[4].ToString());
                
                Robot[0].transform.position = new Vector3(robots[0].x, 1, robots[0].y);
                Robot[1].transform.position = new Vector3(robots[1].x, 1, robots[1].y);
                Robot[2].transform.position = new Vector3(robots[2].x, 1, robots[2].y);
                Robot[3].transform.position = new Vector3(robots[3].x, 1, robots[3].y);
                Robot[4].transform.position = new Vector3(robots[4].x, 1, robots[4].y);

                Robot[5].transform.position = new Vector3(robots[5].x, 0, robots[5].y);
                Robot[6].transform.position = new Vector3(robots[6].x, 0, robots[6].y);
                Robot[7].transform.position = new Vector3(robots[7].x, 0, robots[7].y);
                Robot[8].transform.position = new Vector3(robots[8].x, 0, robots[8].y);
                Robot[9].transform.position = new Vector3(robots[9].x, 0, robots[9].y);
                Robot[10].transform.position = new Vector3(robots[10].x, 0, robots[10].y);
                Robot[11].transform.position = new Vector3(robots[11].x, 0, robots[11].y);
                Robot[12].transform.position = new Vector3(robots[12].x, 0, robots[12].y);
                Robot[13].transform.position = new Vector3(robots[13].x, 0, robots[13].y);
                Robot[14].transform.position = new Vector3(robots[14].x, 0, robots[14].y);
                Robot[15].transform.position = new Vector3(robots[15].x, 0, robots[15].y);
                Robot[16].transform.position = new Vector3(robots[16].x, 0, robots[16].y);
                Robot[17].transform.position = new Vector3(robots[17].x, 0, robots[17].y);
                Robot[18].transform.position = new Vector3(robots[18].x, 0, robots[18].y);
                Robot[19].transform.position = new Vector3(robots[19].x, 0, robots[19].y);
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        timer += Time.deltaTime;
        if (timer > waitTime)
        {
            StartCoroutine(UpdatePositions());
            timer = timer - waitTime;
        }
    }
}