import flask
from flask.json import jsonify
import uuid
from ActInt import Maze

games = {}

app = flask.Flask(__name__)

@app.route("/games", methods=["POST"])
def create():
    global games
    id = str(uuid.uuid4())
    games[id] = Maze()
    return "ok", 201, {'Location': f"/games/{id}"}


@app.route("/games/<id>", methods=["GET"])
def queryState(id):
    global model
    model = games[id]
    model.step()
    Robot1 = model.schedule.agents[56]
    Robot2 = model.schedule.agents[57]
    Robot3 = model.schedule.agents[58]
    Robot4 = model.schedule.agents[59]
    Robot5 = model.schedule.agents[60]

    Robot6 = model.schedule.agents[61]
    Robot7 = model.schedule.agents[62]
    Robot8 = model.schedule.agents[63]
    Robot9 = model.schedule.agents[64]
    Robot10 = model.schedule.agents[65]
    Robot11 = model.schedule.agents[66]
    Robot12 = model.schedule.agents[67]
    Robot13 = model.schedule.agents[68]
    Robot14 = model.schedule.agents[69]
    Robot15 = model.schedule.agents[70]
    Robot16 = model.schedule.agents[71]
    Robot17 = model.schedule.agents[72]
    Robot18 = model.schedule.agents[73]
    Robot19 = model.schedule.agents[74]
    Robot20 = model.schedule.agents[75]

    return jsonify({ "Items": [{"x": Robot1.pos[0], "y": Robot1.pos[1]},{"x": Robot2.pos[0], "y": Robot2.pos[1]},
    {"x": Robot3.pos[0], "y": Robot3.pos[1]},{"x": Robot4.pos[0], "y": Robot4.pos[1]}, {"x": Robot5.pos[0], "y": Robot5.pos[1]}, 
    {"x": Robot6.pos[0], "y": Robot6.pos[1]},{"x": Robot7.pos[0], "y": Robot7.pos[1]},{"x": Robot8.pos[0], "y": Robot8.pos[1]},
    {"x": Robot9.pos[0], "y": Robot9.pos[1]},{"x": Robot10.pos[0], "y": Robot10.pos[1]},{"x": Robot11.pos[0], "y": Robot11.pos[1]},
    {"x": Robot12.pos[0], "y": Robot12.pos[1]},{"x": Robot13.pos[0], "y": Robot13.pos[1]},{"x": Robot14.pos[0], "y": Robot14.pos[1]},
    {"x": Robot15.pos[0], "y": Robot15.pos[1]},{"x": Robot16.pos[0], "y": Robot16.pos[1]},{"x": Robot17.pos[0], "y": Robot17.pos[1]},
    {"x": Robot18.pos[0], "y": Robot18.pos[1]},{"x": Robot19.pos[0], "y": Robot19.pos[1]},{"x": Robot20.pos[0], "y": Robot20.pos[1]} ] } )

app.run()
